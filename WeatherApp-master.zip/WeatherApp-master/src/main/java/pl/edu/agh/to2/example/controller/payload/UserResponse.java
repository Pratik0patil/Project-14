package pl.edu.agh.to2.example.controller.payload;

public record UserResponse(String token) {
}
